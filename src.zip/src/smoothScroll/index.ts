// export { default } from '../utils/scroll'
import smoothScroll from '../utils/scroll';
export default smoothScroll;
