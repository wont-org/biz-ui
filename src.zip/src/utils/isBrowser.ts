export default !!(typeof window !== 'undefined' && window);
